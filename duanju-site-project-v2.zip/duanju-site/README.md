# 短剧场（Drama Space）——可部署网站原型

## 本地运行
需要 Node.js 20+。

```bash
npm install
npm run dev
```

打开 Vite 输出的地址（通常是 `http://localhost:5173`）。`npm run dev` 会同时启动前端与 Express 后端；后端 API 在 3000 端口。

生产运行：
```bash
npm install
npm start
```
然后访问 `http://localhost:3000`。

## 接入搜索 API
设置环境变量：
- `SEARCH_API_URL`：你有权使用的搜索 API endpoint，服务端会追加 `?q=搜索词`。
- `SEARCH_API_KEY`：API key。

API 返回 JSON 示例：
```json
{
  "results": [
    {
      "title": "短剧标题",
      "url": "https://example.com/watch/123",
      "desc": "内容简介",
      "source": "授权片源",
      "playbackUrl": "https://cdn.example.com/video.mp4",
      "quality": "1080p",
      "authorizedEmbed": true
    }
  ]
}
```
适配真实搜索服务时，需要按服务商文档调整 `server.js` 的认证和响应格式。没有配置时，后端会返回多个公开搜索入口；这不等于已完成自动全网索引。

## 站内播放
- 只有返回了 `playbackUrl` 的结果才会出现站内播放按钮。
- 当前播放器支持浏览器可直接播放的 MP4 等直链。HLS (`.m3u8`) 在部分浏览器需加入 `hls.js`；可以在后续版本接入。
- `authorizedEmbed` 是来源元数据，不会自动赋予播放权。请只使用你拥有版权或明确获授权、且允许嵌入/直链播放的视频。
- 普通搜索网页 URL 不是视频流 URL。此项目不会绕过登录、付费墙、DRM 或平台的反嵌入限制。

## 当前版本边界
- 示例海报、剧名、集数为 UI 演示，不是真实片库。
- 本项目已具备前后端骨架、搜索 API 接口、搜索结果渲染和直接视频 URL 播放能力。
- 真正的全网搜索、片源可用性检测、高清片库、在线托管需要配置真实服务、授权视频源和部署环境。
