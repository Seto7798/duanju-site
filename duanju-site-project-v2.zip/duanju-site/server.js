import express from 'express';
import cors from 'cors';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(cors());
app.use(express.json({ limit: '100kb' }));

const PORT = Number(process.env.PORT || 3000);
const providers = [
  { key: 'youtube', name: 'YouTube', build: q => `https://www.youtube.com/results?search_query=${encodeURIComponent(q + ' 短剧 官方 全集')}` },
  { key: 'bilibili', name: '哔哩哔哩', build: q => `https://search.bilibili.com/all?keyword=${encodeURIComponent(q + ' 短剧')}` },
  { key: 'baidu', name: '百度', build: q => `https://www.baidu.com/s?wd=${encodeURIComponent(q + ' 短剧 官方 全集')}` },
  { key: 'douyin', name: '抖音', build: q => `https://www.douyin.com/search/${encodeURIComponent(q)}` },
  { key: 'kuaishou', name: '快手', build: q => `https://www.kuaishou.com/search/video?searchKey=${encodeURIComponent(q)}` }
];

app.get('/api/health', (_req, res) => res.json({
  ok: true,
  service: 'duanju-search',
  searchConfigured: Boolean(process.env.SEARCH_API_URL && process.env.SEARCH_API_KEY),
  playback: 'authorized-direct-video-url-only'
}));

app.get('/api/search', async (req, res) => {
  const q = String(req.query.q || '').trim().slice(0, 180);
  if (!q) return res.status(400).json({ error: '请输入搜索关键词', results: [] });

  const endpoint = process.env.SEARCH_API_URL;
  const key = process.env.SEARCH_API_KEY;
  if (endpoint && key) {
    try {
      const url = new URL(endpoint);
      url.searchParams.set('q', q);
      const response = await fetch(url, {
        headers: { 'Authorization': `Bearer ${key}`, 'Accept': 'application/json' },
        signal: AbortSignal.timeout(10000)
      });
      if (!response.ok) throw new Error(`Provider status ${response.status}`);
      const payload = await response.json();
      const results = Array.isArray(payload.results) ? payload.results.slice(0, 40).map((item, i) => ({
        id: String(item.id || `${i}-${item.url || ''}`),
        title: String(item.title || '未命名结果').slice(0, 300),
        url: String(item.url || ''),
        desc: String(item.desc || item.snippet || '').slice(0, 800),
        source: String(item.source || new URL(item.url).hostname).slice(0, 100),
        playbackUrl: typeof item.playbackUrl === 'string' ? item.playbackUrl : null,
        quality: typeof item.quality === 'string' ? item.quality : null,
        authorizedEmbed: item.authorizedEmbed === true
      })).filter(item => {
        try { const u = new URL(item.url); return ['http:', 'https:'].includes(u.protocol); } catch { return false; }
      }) : [];
      return res.json({ query: q, configured: true, results });
    } catch (err) {
      console.error('Search provider error:', err.message);
      return res.status(502).json({ error: '搜索服务暂时不可用，请检查 API 地址、密钥和返回格式。', results: [] });
    }
  }

  return res.json({
    query: q,
    configured: false,
    message: '未配置搜索服务。当前先返回各平台的公开搜索入口。',
    results: providers.map(p => ({
      id: p.key, title: `在 ${p.name} 搜索「${q}」`,
      url: p.build(q), desc: `在 ${p.name} 查找相关短剧与官方片源`,
      source: p.name, playbackUrl: null, authorizedEmbed: false
    }))
  });
});

// Optional direct playback endpoint validates a supplied URL before the browser uses it.
// It deliberately does not proxy/download video streams.
app.post('/api/playback/check', (req, res) => {
  const raw = String(req.body?.url || '');
  try {
    const u = new URL(raw);
    if (!['http:', 'https:'].includes(u.protocol)) return res.status(400).json({ ok: false, reason: '仅支持 HTTP/HTTPS 地址' });
    return res.json({ ok: true, url: u.toString(), note: '该检查只验证地址格式，不代表视频授权、可访问性或清晰度。' });
  } catch {
    return res.status(400).json({ ok: false, reason: '播放地址格式无效' });
  }
});

const dist = path.join(__dirname, 'dist');
app.use(express.static(dist));
app.get('*', (_req, res, next) => {
  res.sendFile(path.join(dist, 'index.html'), err => { if (err) next(); });
});
app.listen(PORT, '0.0.0.0', () => console.log(`Drama Space server listening on port ${PORT}`));
