import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Search, Play, Film, Clock3, Heart, ChevronRight, ArrowLeft, ExternalLink, Sparkles, Tv, X, Subtitles } from 'lucide-react';
import './style.css';

const categories = ['全部', '都市情感', '甜宠爱情', '逆袭复仇', '古装传奇', '家庭伦理', '悬疑反转'];
const demo = [
 {id:'d1',title:'当爱意消散时',desc:'爱与选择之间，每一步都改变结局。',genre:'都市情感',episodes:60,tag:'情感',color:'rose',symbol:'♡',year:'2026',source:'示例内容',url:'https://www.youtube.com/results?search_query='+encodeURIComponent('短剧 当爱意消散时 官方全集')},
 {id:'d2',title:'重启人生后我赢麻了',desc:'重新来过，这一次不再任人摆布。',genre:'逆袭复仇',episodes:72,tag:'逆袭',color:'gold',symbol:'↗',year:'2026',source:'示例内容',url:'https://www.youtube.com/results?search_query='+encodeURIComponent('重启人生后我赢麻了 短剧 官方')},
 {id:'d3',title:'偏偏宠爱你',desc:'一场意外，让两条人生轨迹相遇。',genre:'甜宠爱情',episodes:48,tag:'甜宠',color:'purple',symbol:'✦',year:'2025',source:'示例内容',url:'https://www.youtube.com/results?search_query='+encodeURIComponent('偏偏宠爱你 短剧 官方全集')},
 {id:'d4',title:'长安月下',desc:'风起长安，旧案与真心逐渐浮现。',genre:'古装传奇',episodes:80,tag:'古装',color:'green',symbol:'月',year:'2026',source:'示例内容',url:'https://www.youtube.com/results?search_query='+encodeURIComponent('古装短剧 长安月下 官方全集')},
 {id:'d5',title:'她的第二人生',desc:'走出困局，找回属于自己的生活。',genre:'家庭伦理',episodes:55,tag:'女性',color:'blue',symbol:'她',year:'2025',source:'示例内容',url:'https://www.youtube.com/results?search_query='+encodeURIComponent('她的第二人生 短剧 官方')},
 {id:'d6',title:'最后一封来信',desc:'每一封信背后，都藏着未说出口的秘密。',genre:'悬疑反转',episodes:36,tag:'悬疑',color:'dark',symbol:'？',year:'2026',source:'示例内容',url:'https://www.youtube.com/results?search_query='+encodeURIComponent('悬疑短剧 最后一封来信 官方全集')}
];
const sources = [
 {name:'YouTube',desc:'官方频道与公开授权视频',key:'youtube'},
 {name:'Bilibili',desc:'投稿短剧与官方账号',key:'bilibili'},
 {name:'百度',desc:'网页索引与剧名线索',key:'baidu'},
 {name:'抖音',desc:'短剧片段与官方账号',key:'douyin'},
 {name:'快手',desc:'短剧与创作者内容',key:'kuaishou'}
];
function searchUrl(key,q){
 const s=encodeURIComponent(q+' 短剧 官方 全集');
 return ({youtube:`https://www.youtube.com/results?search_query=${s}`,bilibili:`https://search.bilibili.com/all?keyword=${s}`,baidu:`https://www.baidu.com/s?wd=${s}`,douyin:`https://www.douyin.com/search/${encodeURIComponent(q)}`,kuaishou:`https://www.kuaishou.com/search/video?searchKey=${encodeURIComponent(q)}`})[key];
}
function App(){
 const [query,setQuery]=useState(''); const [active,setActive]=useState('全部'); const [page,setPage]=useState('home');
 const [selected,setSelected]=useState(null); const [results,setResults]=useState([]); const [loading,setLoading]=useState(false); const [error,setError]=useState('');
 const [history,setHistory]=useState(()=>JSON.parse(localStorage.getItem('dramaHistory')||'[]'));
 const [favorites,setFavorites]=useState(()=>JSON.parse(localStorage.getItem('dramaFavs')||'[]'));
 const [showSources,setShowSources]=useState(false);
 const [provider,setProvider]=useState('youtube');
 useEffect(()=>{localStorage.setItem('dramaHistory',JSON.stringify(history))},[history]);
 useEffect(()=>{localStorage.setItem('dramaFavs',JSON.stringify(favorites))},[favorites]);
 const search=async(q=query)=>{
   q=q.trim(); if(!q)return;
   setQuery(q);setPage('search');setLoading(true);setError('');setSelected(null);
   try{
     const r=await fetch('/api/search?q='+encodeURIComponent(q));
     if(r.ok){const data=await r.json(); if(Array.isArray(data.results)&&data.results.length){setResults(data.results);setLoading(false);return;}}
   }catch(e){}
   setResults(sources.map(s=>({...s,url:searchUrl(s.key,q),title:`在 ${s.name} 搜索「${q}」`,isExternal:true})));
   setError('尚未配置外部搜索 API。以下是按关键词生成的搜索入口；接入搜索服务后，可在此显示统一结果列表。');
   setLoading(false);
 };
 const openDemo=d=>{setSelected(d);setPage('player');setHistory(h=>[d,...h.filter(x=>x.id!==d.id)].slice(0,8));};
 const toggleFav=d=>setFavorites(f=>f.some(x=>x.id===d.id)?f.filter(x=>x.id!==d.id):[d,...f]);
 const goHome=()=>{setPage('home');setSelected(null);setError('');};
 const cards=demo.filter(d=>(active==='全部'||d.genre===active)&&(!query||page!=='home'||d.title.includes(query)||d.genre.includes(query)));
 return <div className="app">
  <header className="topbar"><button className="brand" onClick={goHome}><span className="brandmark"><Play size={18} fill="currentColor"/></span><span>短剧场<small>DRAMA SPACE</small></span></button>
   <nav><button className={page==='home'?'nav-active':''} onClick={goHome}>首页</button><button className={page==='search'?'nav-active':''} onClick={()=>{setPage('search');setResults([])}}>找短剧</button><button className={page==='favorites'?'nav-active':''} onClick={()=>setPage('favorites')}>我的收藏</button></nav>
  </header>
  {page==='player'&&selected?<main className="page player-page"><button className="back" onClick={goHome}><ArrowLeft size={17}/> 返回首页</button><div className="player-layout"><section className="video-panel">{selected.playbackUrl&&/^https?:\\/\\//i.test(selected.playbackUrl)?<div className="native-video"><video controls playsInline preload="metadata" src={selected.playbackUrl}>你的浏览器不支持 HTML5 视频播放。</video></div>:<div className="video-placeholder"><div className="play-circle"><Play size={28} fill="currentColor"/></div><h2>{selected.title}</h2><p>该结果没有提供可直接播放的授权视频地址</p><a className="primary-btn" href={selected.url} target="_blank" rel="noreferrer"><ExternalLink size={16}/> 查看来源</a></div>}<div className="video-meta"><div><h1>{selected.title}</h1><p>{selected.genre} · {selected.year} · {selected.episodes} 集（演示信息）</p></div><button className={'icon-btn '+(favorites.some(x=>x.id===selected.id)?'liked':'')} onClick={()=>toggleFav(selected)}><Heart size={19} fill={favorites.some(x=>x.id===selected.id)?'currentColor':'none'}/></button></div><p className="desc">{selected.desc}</p></section><aside className="episode-panel"><h3>选集 <span>共 {selected.episodes} 集（示例）</span></h3><div className="episode-grid">{Array.from({length:Math.min(selected.episodes,60)},(_,i)=><button key={i} onClick={()=>{}} className={i===0?'episode-active':''}>{i+1}</button>)}</div><p className="muted tiny">集数为界面演示。接入真实授权片源后才会显示可播放剧集。</p></aside></div></main>
  :page==='favorites'?<main className="page"><div className="page-heading"><span className="eyebrow">YOUR COLLECTION</span><h1>我的收藏</h1><p>喜欢的故事，留在这里。</p></div>{favorites.length?<div className="drama-grid">{favorites.map(d=><DramaCard key={d.id} d={d} onClick={()=>openDemo(d)} fav={true} toggleFav={toggleFav}/>)}</div>:<div className="empty"><Heart size={28}/><h3>还没有收藏</h3><p>遇到喜欢的短剧，可以点爱心保存。</p><button className="primary-btn" onClick={goHome}>去逛逛</button></div>}</main>
  :page==='search'?<main className="page"><div className="page-heading search-heading"><span className="eyebrow">FIND YOUR NEXT STORY</span><h1>搜一搜，找到想看的</h1><p>搜索授权片源与公开索引；不同平台的播放权限可能不同。</p><form className="searchbox large-search" onSubmit={e=>{e.preventDefault();search()}}><Search size={21}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="输入短剧名、演员或关键词"/><button className="primary-btn">搜索</button></form><div className="quick-tags">{['霸总短剧','重生复仇','先婚后爱','古装短剧','短剧全集'].map(t=><button key={t} onClick={()=>search(t)}>{t}</button>)}</div></div>
   {loading?<div className="empty"><div className="loader"></div><p>正在查找相关片源…</p></div>:<>{error&&<div className="notice"><Sparkles size={17}/><span>{error}</span></div>}{results.length>0&&<><div className="section-head"><h2>搜索结果</h2><span>{results.length} 个入口</span></div><div className="result-list">{results.map((r,i)=><article className="result-card" key={r.key||r.id||r.url||i}><div className="source-icon"><Tv size={20}/></div><div className="result-info"><h3>{r.title||r.name}</h3><p>{r.desc||'公开索引结果'}{r.quality?' · '+r.quality:''}{r.playbackUrl?' · 可用播放地址':''}</p></div>{r.playbackUrl&&/^https?:\\/\\//i.test(r.playbackUrl)?<button className="result-link result-play" onClick={()=>{setSelected({id:r.id||r.url,title:r.title||'短剧',desc:r.desc||'',genre:r.source||'在线片源',episodes:1,year:'',url:r.url,playbackUrl:r.playbackUrl,authorizedEmbed:r.authorizedEmbed});setPage('player')}}>站内播放 <Play size={14}/></button>:<a href={r.url} target="_blank" rel="noreferrer" className="result-link">查看来源 <ExternalLink size={14}/></a>}</article>)}</div></>}</>}
  </main>
  :<><section className="hero"><div className="hero-inner"><span className="eyebrow"><Sparkles size={14}/> 每一集，都是新故事</span><h1>今晚，想看点什么？</h1><p>从心动到反转，总有一部短剧合你心意。</p><form className="searchbox" onSubmit={e=>{e.preventDefault();search()}}><Search size={21}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="搜剧名、题材、演员…"/><button className="primary-btn">搜索</button></form><div className="hero-foot"><span><Film size={14}/> 精选短剧目录</span><span><Clock3 size={14}/> 记录最近观看</span><span><Heart size={14}/> 本地收藏</span></div></div><div className="hero-art"><div className="art-orbit orbit-one"></div><div className="art-orbit orbit-two"></div><div className="art-card art-back"><span>STORY</span><b>转折</b></div><div className="art-card art-front"><span>EPISODE 01</span><b>心动<br/>发生时</b><i>▶</i></div><div className="art-spark">✳</div></div></section>
  <main className="page home-page"><div className="category-row">{categories.map(c=><button key={c} onClick={()=>setActive(c)} className={active===c?'cat-active':''}>{c}</button>)}</div><div className="section-head"><div><span className="eyebrow">HANDPICKED FOR YOU</span><h2>{active==='全部'?'今日精选':active}</h2></div><button className="text-link" onClick={()=>{setPage('search');setResults([])}}>探索全部 <ChevronRight size={16}/></button></div><div className="drama-grid">{cards.map(d=><DramaCard key={d.id} d={d} onClick={()=>openDemo(d)} fav={favorites.some(x=>x.id===d.id)} toggleFav={toggleFav}/>)}</div><div className="source-section"><div><span className="eyebrow">ONE SEARCH, MANY SOURCES</span><h2>片源搜索</h2><p>在一个页面整理多个公开来源的检索入口。</p></div><button className="outline-btn" onClick={()=>{setPage('search');setResults([])}}>开始搜索 <ChevronRight size={16}/></button></div><div className="source-chips">{sources.map(s=><button key={s.key} onClick={()=>{setQuery('');setPage('search');setResults([{...s,url:searchUrl(s.key,'短剧'),title:'在 '+s.name+' 搜索短剧',isExternal:true}]);setError('这是外部公开搜索入口，当前不会自动抓取其内部视频。')}}><span className="source-dot"></span>{s.name}<ExternalLink size={13}/></button>)}</div></main></>}
  <footer><div className="footer-brand">短剧场 <span>DRAMA SPACE</span></div><p>聚合检索工具 · 请支持正版与授权内容</p><p className="footer-small">目前为可运行的前端原型。全网实时搜索需要配置搜索 API，站内播放需要可嵌入的授权视频地址。</p></footer>
 </div>
}
function DramaCard({d,onClick,fav,toggleFav}){
 return <article className="drama-card"><button className={'poster poster-'+d.color} onClick={onClick}><span className="poster-top">{d.year} · SHORT DRAMA</span><span className="poster-symbol">{d.symbol}</span><span className="poster-title">{d.title}</span><span className="poster-bottom">{d.tag}　·　{d.episodes} 集（示例）</span><span className="poster-play"><Play size={17} fill="currentColor"/></span></button><div className="drama-details"><button className="drama-title" onClick={onClick}>{d.title}</button><button className={'mini-heart '+(fav?'liked':'')} onClick={()=>toggleFav(d)} aria-label="收藏"><Heart size={17} fill={fav?'currentColor':'none'}/></button><p>{d.genre} <span>·</span> {d.desc}</p></div></article>
}
createRoot(document.getElementById('root')).render(<App/>);